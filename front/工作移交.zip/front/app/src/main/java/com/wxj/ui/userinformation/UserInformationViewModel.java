package com.wxj.ui.userinformation;

import androidx.lifecycle.ViewModel;

public class UserInformationViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}