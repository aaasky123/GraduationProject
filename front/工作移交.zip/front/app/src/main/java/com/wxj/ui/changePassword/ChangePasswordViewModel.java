package com.wxj.ui.changePassword;

import androidx.lifecycle.ViewModel;

public class ChangePasswordViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}