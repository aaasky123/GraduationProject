package com.wxj.ui.userinformation;

import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wxj.R;

public class UserInformationFragment extends Fragment {

    private UserInformationViewModel mViewModel;
    private TextView user_name;
    private TextView email;
    private TextView company;
    private TextView employeeId;

    public static UserInformationFragment newInstance() {
        return new UserInformationFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.user_information_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(UserInformationViewModel.class);
        // TODO: Use the ViewModel
        user_name.findViewById(R.id.textView6);
        email.findViewById(R.id.textView8);
        company.findViewById(R.id.textView10);
        employeeId.findViewById(R.id.textView12);
        Intent intent= Intent.getIntent();
    }

}