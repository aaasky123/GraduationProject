package com.wxj.ui.me;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.wxj.MainActivity;
import com.wxj.R;
import com.wxj.ui.about.AboutFragment;
import com.wxj.ui.login.LoginActivity;
import com.wxj.ui.userinformation.UserInformationFragment;

import org.json.JSONException;
import org.json.JSONObject;

import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.CropCircleTransformation;

public class MeFragment extends Fragment {

    private MeViewModel meViewModel;

    private ImageView headPictureBack;
    private ImageView headPicture;
    private TextView user_name;
    private TextView userBelongsTo;
    private Button cancelLogin;

    private LinearLayout userInformation;
    private LinearLayout changePassword;
    private LinearLayout about;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,@Nullable Bundle savedInstanceState) {
        //meViewModel =
        //        ViewModelProviders.of(this).get(MeViewModel.class);
        //View root = inflater.inflate(R.layout.fragment_me, container, false);
        //final TextView textView = root.findViewById(R.id.text_me);
        //meViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
        //    @Override
        //    public void onChanged(@Nullable String s) {
        //        textView.setText(s);
        //    }
        //});
        //return root;
        return inflater.inflate(R.layout.fragment_me,container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view,savedInstanceState);
        headPictureBack=view.findViewById(R.id.head_picture_back);
        headPicture=view.findViewById(R.id.head_picture);
        user_name=view.findViewById(R.id.username);
        userBelongsTo=view.findViewById(R.id.user_belongs_to);
        cancelLogin=view.findViewById(R.id.btn_cancel_login);
        userInformation=view.findViewById(R.id.user_information);
        changePassword=view.findViewById(R.id.change_password);
        about=view.findViewById(R.id.about);
        cancelLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences=getActivity().getSharedPreferences("logindata", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.clear();
                editor.commit();
                startActivity(new Intent(getActivity(), LoginActivity.class));
            }
        });

        userInformation.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(final View view){
                SharedPreferences read2=getActivity().getSharedPreferences("logindata",Context.MODE_PRIVATE);
                String number=read2.getString("number","");
                JSONObject jsonObject=new JSONObject();
                try {
                    jsonObject.put("number",number);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String url="http://192.168.88.138:55555/user/userInformation";
                RequestQueue requestQueue = Volley.newRequestQueue(getContext());
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObject, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        try {
                            String msg = jsonObject.getString("msg");
                            Log.d("msg", msg);
                            if (msg.equals("登录成功")) {

                                JSONObject detail = jsonObject.getJSONObject("information");
                                String number = detail.getString("number");
                                String password = detail.getString("password");
                                String picture=detail.getString("picture");
                                String realName = detail.getString("realName");
                                String email = detail.getString("email");
                                String company_id=detail.getString("company_id");
                                String employee_id=detail.getString("employee_id");
                                Bundle bundle=new Bundle();
                                Intent intent=new Intent(getContext(), UserInformationFragment.class);
                                bundle.putString("number",number);
                                bundle.putString("password",password);
                                bundle.putString("picture",picture);
                                bundle.putString("realName",realName);
                                bundle.putString("email",email);
                                bundle.putString("company_id",company_id);
                                bundle.putString("employee_id",employee_id);
                                intent.putExtra("user_information_detail",bundle);


                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        Toast.makeText(getContext(), "网络出错", Toast.LENGTH_SHORT).show();
                    }
                });
                requestQueue.add(jsonObjectRequest);
                Navigation.findNavController(view).navigate(R.id.navigation_user_information);
            }
        });
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.navigation_change_password);
                //startActivity(new Intent(getActivity(), ChangePasswordActivity.class));
            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.navigation_about);
                //startActivity(new Intent(getActivity(), AboutActivity.class));
            }
        });
        SharedPreferences read=getActivity().getSharedPreferences("logindata",Context.MODE_PRIVATE);
        String username = read.getString("number","");
        user_name.setText(username);
        //String companyId=read.getString("companyId","");
        //userBelongsTo.setText(companyId);
        Glide.with(getActivity()).load(R.drawable.headphoto).bitmapTransform(new BlurTransformation(getActivity(),25),new CenterCrop(getActivity())).into(headPictureBack);
        Glide.with(getActivity()).load(R.drawable.headphoto).bitmapTransform(new CropCircleTransformation(getActivity())).into(headPicture);
    }

}
