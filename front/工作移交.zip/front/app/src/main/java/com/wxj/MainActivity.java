package com.wxj;

import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //获取BottomNavigationView实例
        BottomNavigationView navView = findViewById(R.id.nav_view);

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.

        //通过navController.getGraph()这个方法获取navigation中的导航配置，并创建appBarConfiguration配置文件
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_work, R.id.navigation_notifications, R.id.navigation_contactpeople, R.id.navigation_me)
                .build();

        //获取Navigation的hostFragment
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        //将appBarConfiguration配置文件和navController关联，此时关联的是ActionBar中的menu
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        //装配navController到BottomNavigationView上实现页面切换
        NavigationUI.setupWithNavController(navView, navController);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController=Navigation.findNavController(this,R.id.nav_host_fragment);
        return navController.navigateUp();
        //return super.onSupportNavigateUp();
    }
}